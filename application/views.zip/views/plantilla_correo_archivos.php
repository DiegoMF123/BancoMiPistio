<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta http-equiv="content-type" content="text/html; utf-8">
	<title>

	</title>
</head>
<body>


	<table align="center" accept-charset="UTF-8">

		<tr>

		</tr>
			  <td>
                                                        <table >
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table>
                                                                            <tbody>
                                                                                <tr>
                                                                                    <br>

                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>




		<tr>

			<td  align="left">
              <br>
              <p align ="left">
								Señor cuentahabiente,  agradecemos su comunicación,  le informamos que su queja ha sido recibida exitosamente. Para el seguimiento o cualquier consulta relacionada, no olvide que el número de su queja es: <?php echo $correlativo; ?>

							</p>

              <u>

                     <br>
                    <br>

                     <b><p>Gracias por utilizar la plataforma....</p></b>

               <b><p>Atentamente, el equipo de Banco Mi Pistio.</p></b>
            </td>




		</tr>

		<tr>


			<td align="center" style="background: #00e1d4; color: #fff; margin: 50; padding: 50; "  >

				<i><p>BMP</p>
                                                                                        <p>Calzada San Juan 2-16</p>


                                                                                        <p>Banco Mi Pistio!    Simepre de tu lado.
                                                                                        </p><i>



				<table >
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td align="center"><a target="_blank" ><img title="Facebook" src="https://fezlwh.stripocdn.email/content/assets/img/social-icons/logo-black/facebook-logo-black.png" alt="Fb" width="32"></a></td>
                                                                                                    <td align="center"><a target="_blank" ><img title="Twitter" src="https://fezlwh.stripocdn.email/content/assets/img/social-icons/logo-black/twitter-logo-black.png" alt="Tw" width="32"></a></td>
                                                                                                    <td align="center"><a target="_blank" ><img title="Instagram" src="https://fezlwh.stripocdn.email/content/assets/img/social-icons/logo-black/instagram-logo-black.png" alt="Inst" width="32"></a></td>

                                                                                                </tr>


                                                                                            </tbody>
                                                                                        </table>

                                                                                           <p align="center">&#169;  2020 Banco Mi Pistio</p>





			</td>


		</tr>


		<tr>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>

		<center><img  src="https://i.ibb.co/YRG8Znj/BMP.png"  width="600"></center>





		</tr>


	</table>







</body>
</html>
